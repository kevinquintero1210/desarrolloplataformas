// botonl.js - Versión mejorada con efectos para PROYECT4

// Esperar a que el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 PROYECT4 - Estudio Creativo inicializado');
    
    // Inicializar todas las funcionalidades
    initLoginButton();
    initCardEffects();
    initSmoothScroll();
    initLogoInteractions();
    initPageLoadEffect();
});

// ============================================
// 1. BOTÓN DE LOGIN MEJORADO
// ============================================
function initLoginButton() {
    const loginBtn = document.getElementById('loginBtn');
    
    if (loginBtn) {
        loginBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Guardar contenido original
            const originalHTML = this.innerHTML;
            const originalWidth = this.offsetWidth;
            
            // Establecer ancho fijo para evitar saltos
            this.style.width = `${originalWidth}px`;
            this.style.justifyContent = 'center';
            
            // Efecto de carga
            this.innerHTML = `
                <div class="login-loading">
                    <div class="spinner"></div>
                    <span>ACCEDIENDO...</span>
                </div>
            `;
            this.disabled = true;
            
            // Simular proceso de autenticación
            setTimeout(() => {
                // Restaurar botón
                this.innerHTML = originalHTML;
                this.disabled = false;
                this.style.width = '';
                this.style.justifyContent = '';
                
                // Mostrar mensaje de estado
                showNotification('Sistema de autenticación en desarrollo', 'info');
                
                // En producción, redirigiría a:
                // window.location.href = 'login.html';
                
            }, 1800);
        });
        
        // Agregar estilos para el spinner
        const style = document.createElement('style');
        style.textContent = `
            .login-loading {
                display: flex;
                align-items: center;
                gap: 12px;
            }
            
            .spinner {
                width: 18px;
                height: 18px;
                border: 2px solid rgba(255, 255, 255, 0.3);
                border-radius: 50%;
                border-top-color: #ffffff;
                animation: spin 0.8s linear infinite;
            }
            
            @keyframes spin {
                to { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(style);
    }
}

// ============================================
// 2. EFECTOS PARA TARJETAS
// ============================================
function initCardEffects() {
    const cards = document.querySelectorAll('.card');
    
    cards.forEach((card, index) => {
        // Retraso escalonado para animación de entrada
        card.style.animationDelay = `${index * 0.1}s`;
        
        // Efecto de hover con parámetros dinámicos
        card.addEventListener('mouseenter', function(e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            // Crear efecto de luz dinámico
            this.style.setProperty('--mouse-x', `${x}px`);
            this.style.setProperty('--mouse-y', `${y}px`);
            
            // Agregar clase activa
            this.classList.add('card-active');
            
            // Sonido sutil (opcional)
            playHoverSound();
        });
        
        card.addEventListener('mouseleave', function() {
            this.classList.remove('card-active');
        });
        
        // Click en tarjeta
        card.addEventListener('click', function(e) {
            if (!e.target.closest('a')) {
                const link = this.querySelector('a.card-link');
                if (link) {
                    // Efecto de click
                    this.style.transform = 'scale(0.98)';
                    setTimeout(() => {
                        this.style.transform = '';
                        // window.location.href = link.href;
                    }, 200);
                }
            }
        });
    });
    
    // Agregar estilos para el efecto de luz
    const cardStyle = document.createElement('style');
    cardStyle.textContent = `
        .card-active {
            position: relative;
            overflow: hidden;
        }
        
        .card-active::before {
            content: '';
            position: absolute;
            top: calc(var(--mouse-y, 0px) - 100px);
            left: calc(var(--mouse-x, 0px) - 100px);
            width: 200px;
            height: 200px;
            background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
            pointer-events: none;
            z-index: 1;
            opacity: 0.5;
        }
    `;
    document.head.appendChild(cardStyle);
}

// ============================================
// 3. SCROLL SUAVE
// ============================================
function initSmoothScroll() {
    // Para enlaces internos
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            
            if (targetId !== '#') {
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 100,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
    
    // Efecto de aparición al hacer scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);
    
    // Observar elementos que queremos animar al scroll
    document.querySelectorAll('.card, .info-card').forEach(el => {
        observer.observe(el);
    });
}

// ============================================
// 4. INTERACCIONES CON EL LOGO
// ============================================
function initLogoInteractions() {
    const logoContainer = document.querySelector('.logo-animated');
    
    if (logoContainer) {
        // Efecto al pasar el mouse sobre el logo
        logoContainer.addEventListener('mouseenter', function() {
            this.style.animationDuration = '2s';
            this.style.transform = 'scale(1.05)';
            
            // Animación especial para cada letra
            const letters = this.querySelectorAll('.logo-block');
            letters.forEach((letter, index) => {
                letter.style.animation = `letter-bounce 0.5s ease ${index * 0.05}s`;
            });
        });
        
        logoContainer.addEventListener('mouseleave', function() {
            this.style.animationDuration = '8s';
            this.style.transform = 'scale(1)';
            
            // Restaurar animación original
            const letters = this.querySelectorAll('.logo-block');
            letters.forEach(letter => {
                letter.style.animation = '';
            });
        });
        
        // Agregar estilos para la animación de bounce
        const logoStyle = document.createElement('style');
        logoStyle.textContent = `
            @keyframes letter-bounce {
                0%, 100% { transform: translateY(0); }
                50% { transform: translateY(-10px); }
            }
        `;
        document.head.appendChild(logoStyle);
        
        // Click en el logo para recargar con efecto
        logoContainer.addEventListener('click', function() {
            this.style.transform = 'scale(0.95)';
            this.style.opacity = '0.8';
            
            setTimeout(() => {
                this.style.transform = '';
                this.style.opacity = '';
                // window.location.reload(); // Para recargar la página
            }, 300);
        });
    }
}

// ============================================
// 5. EFECTO DE CARGA DE PÁGINA
// ============================================
function initPageLoadEffect() {
    // Efecto de fade in
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.8s ease';
    
    setTimeout(() => {
        document.body.style.opacity = '1';
    }, 100);
    
    // Agregar clase de carga completada
    setTimeout(() => {
        document.body.classList.add('page-loaded');
    }, 1000);
    
    // Efecto de progreso de carga (simulado)
    const progressBar = document.createElement('div');
    progressBar.className = 'page-progress';
    progressBar.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 0%;
        height: 3px;
        background: linear-gradient(90deg, #666, #999, #ccc);
        z-index: 9999;
        transition: width 0.3s ease;
    `;
    document.body.appendChild(progressBar);
    
    // Simular progreso
    let progress = 0;
    const interval = setInterval(() => {
        progress += 10;
        progressBar.style.width = `${progress}%`;
        
        if (progress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
                progressBar.style.opacity = '0';
                setTimeout(() => {
                    progressBar.remove();
                }, 500);
            }, 300);
        }
    }, 50);
}

// ============================================
// FUNCIONES AUXILIARES
// ============================================

// Mostrar notificación
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${type === 'info' ? 'info-circle' : 'check-circle'}"></i>
            <span>${message}</span>
        </div>
        <button class="notification-close">&times;</button>
    `;
    
    // Estilos para la notificación
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: rgba(255, 255, 255, 0.95);
        color: #333;
        padding: 15px 20px;
        border-radius: 10px;
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
        z-index: 9999;
        transform: translateX(150%);
        transition: transform 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        max-width: 400px;
    `;
    
    // Estilos para el contenido
    const contentStyle = `
        .notification-content {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .notification-content i {
            font-size: 1.2rem;
        }
        
        .notification-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #666;
            padding: 0;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: background 0.3s ease;
        }
        
        .notification-close:hover {
            background: rgba(0, 0, 0, 0.1);
        }
    `;
    
    // Agregar estilos si no existen
    if (!document.querySelector('#notification-styles')) {
        const styleEl = document.createElement('style');
        styleEl.id = 'notification-styles';
        styleEl.textContent = contentStyle;
        document.head.appendChild(styleEl);
    }
    
    document.body.appendChild(notification);
    
    // Animación de entrada
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 10);
    
    // Configurar botón de cierre
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
        notification.style.transform = 'translateX(150%)';
        setTimeout(() => notification.remove(), 400);
    });
    
    // Auto-remover después de 5 segundos
    setTimeout(() => {
        if (notification.parentNode) {
            notification.style.transform = 'translateX(150%)';
            setTimeout(() => notification.remove(), 400);
        }
    }, 5000);
}

// Sonido de hover (sutil)
function playHoverSound() {
    // Solo reproducir si el usuario ha interactuado con la página
    if (document.body.classList.contains('user-interacted')) {
        try {
            // Crear un sonido sutil usando Web Audio API
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.frequency.value = 800;
            oscillator.type = 'sine';
            
            gainNode.gain.setValueAtTime(0, audioContext.currentTime);
            gainNode.gain.linearRampToValueAtTime(0.02, audioContext.currentTime + 0.01);
            gainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.1);
            
            oscillator.start(audioContext.currentTime);
            oscillator.stop(audioContext.currentTime + 0.1);
        } catch (e) {
            // Fallback silencioso si Web Audio API no está disponible
            console.log('Audio no disponible');
        }
    }
}

// Marcar que el usuario ha interactuado
document.addEventListener('click', function() {
    document.body.classList.add('user-interacted');
}, { once: true });

// ============================================
// MANEJO DE IMÁGENES FALTANTES
// ============================================
function handleImageError(img) {
    console.warn(`Imagen no encontrada: ${img.src}`);
    
    // Intentar cargar imagen de respaldo
    const backupImages = [
        'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1507591064344-4c6ce005-128?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ];
    
    const randomBackup = backupImages[Math.floor(Math.random() * backupImages.length)];
    
    // Solo cambiar una vez para evitar bucles infinitos
    if (!img.hasAttribute('data-fallback-attempted')) {
        img.setAttribute('data-fallback-attempted', 'true');
        img.src = randomBackup;
    }
}

// Configurar manejadores de error para imágenes
document.querySelectorAll('img').forEach(img => {
    img.addEventListener('error', function() {
        handleImageError(this);
    });
});

// ============================================
// EFECTOS DE PERFORMANCE Y OPTIMIZACIÓN
// ============================================

// Lazy loading para imágenes
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src || img.src;
                imageObserver.unobserve(img);
            }
        });
    });
    
    // Observar imágenes con data-src
    document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
    });
}

// Prefetch para enlaces importantes
document.addEventListener('mouseover', function(e) {
    const link = e.target.closest('a');
    if (link && link.href && !link.href.includes(window.location.origin)) {
        const prefetchLink = document.createElement('link');
        prefetchLink.rel = 'prefetch';
        prefetchLink.href = link.href;
        document.head.appendChild(prefetchLink);
    }
});

// Consola de bienvenida
console.log(`
%c🚀 PROYECT4 - Estudio Creativo
%c
✨ Diseño minimalista con animaciones suaves
🎨 Paleta monocromática: Blanco, Negro & Gris
⚡ Performance optimizada
📱 Totalmente responsive

Versión: 2.0 | © 2025 PROYECT4 Team
`, 
'color: #fff; background: #000; padding: 10px; font-size: 16px; font-weight: bold; border-radius: 5px;',
'color: #999; font-size: 12px;'
);
<?php
session_start();

$error = isset($_SESSION['login_error']) ? $_SESSION['login_error'] : '';

// Limpiar el mensaje de error después de usarlo
unset($_SESSION['login_error']);

function showError($error)
{
  return !empty($error) ? "<p class='error-message'>" . htmlspecialchars($error) . "</p>" : '';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <div class="container">
    <div class="form-box active" id="login-form">
      <form action="login.php" method="post">
        <h2>Admin Login</h2>
        <?= showError($error); ?>
        <input type="email" name="email" placeholder="Admin Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" name="login">Login</button>
      </form>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      document.querySelector('input[name="email"]').focus();
    });
  </script>
</body>

</html>
<?php
session_start();

// Verificar que el usuario esté logueado Y sea administrador
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// Determinar qué admin es y cargar su CV específico
$adminEmail = $_SESSION['email'];
$adminName = $_SESSION['name'];

// Mapeo de admins a sus carpetas de CV
$adminCVs = [
    'cristian@gmail.com' => '../cv_cristian/index.html',
    'kevin@gmail.com' => '../cv_kevin/index.html',
    'stefanny@gmail.com' => '../cv_stefanny/index.html',
    'camilo@gmail.com' => '../cv_camilo/index.html'
];

// Función para obtener el contenido del CV
function getCVContent($email, $adminCVs)
{
    if (isset($adminCVs[$email])) {
        $cvFile = $adminCVs[$email];

        // Verificar si el archivo existe
        if (file_exists($cvFile)) {
            return file_get_contents($cvFile);
        } else {
            return "<div style='padding: 40px; text-align: center;'>
                       <h3>CV no encontrado</h3>
                       <p>El archivo CV no está disponible en este momento.</p>
                       <p><small>Ruta buscada: " . htmlspecialchars($cvFile) . "</small></p>
                    </div>";
        }
    }

    return "<div style='padding: 40px; text-align: center;'>
               <h3>CV no configurado</h3>
               <p>Este administrador no tiene un CV asignado.</p>
            </div>";
}

// Obtener el contenido del CV
$cvContent = getCVContent($adminEmail, $adminCVs);

// Obtener la ruta del archivo HTML para el iframe
$cvFilePath = isset($adminCVs[$adminEmail]) ? $adminCVs[$adminEmail] : null;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?= htmlspecialchars($adminName); ?></title>
    <link rel="stylesheet" href="style.css">
    <!-- Incluir html2pdf para generar PDF -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #ffffff !important;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        /* Fuerza el fondo blanco en todos los elementos posibles */
        body::before,
        body::after,
        .app,
        .main-content,
        .page-wrapper,
        [class*="background"],
        [class*="bg-"] {
            background: #ffffff !important;
            background-image: none !important;
        }

        /* Welcome message */
        h1 {
            text-align: center;
            color: #333;
            margin: 40px 0 10px 0;
            font-size: 2.5em;
            width: 100%;
        }

        .admin-name {
            color: #4a6cf7;
        }

        /* Subtítulo */
        p.subtitle {
            text-align: center;
            color: #666;
            margin: 0 0 40px 0;
            font-size: 1.2em;
            width: 100%;
        }

        /* CV content */
        .cv-frame {
            width: 90%;
            max-width: 1200px;
            height: 600px;
            border: none;
            margin: 0 0 40px 0;
            background: white !important;
            border-radius: 10px;
        }

        .cv-content {
            background: white !important;
            padding: 40px;
            width: 90%;
            max-width: 1200px;
            margin: 0 0 40px 0;
            border-radius: 10px;
        }

        /* Botones */
        .button-container {
            display: flex;
            gap: 15px;
            margin-top: auto;
            margin-bottom: 40px;
        }

        .btn {
            padding: 0;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            transition: all 0.3s;
            text-align: center;
            width: 180px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-sizing: border-box;
            line-height: 1;
            text-decoration: none;
            color: white;
            font-family: Arial, sans-serif;
            margin: 0;
        }

        .btn-logout {
            background: #dc3545;
        }

        .btn-logout:hover {
            background: #c82333;
            transform: translateY(-2px);
        }

        .btn-download {
            background: #28a745;
        }

        .btn-download:hover {
            background: #218838;
            transform: translateY(-2px);
        }

        .btn-edit {
            background: #007bff;
        }

        .btn-edit:hover {
            background: #0056b3;
            transform: translateY(-2px);
        }

        /* Estilo para mensajes de error */
        .cv-error {
            text-align: center;
            padding: 40px;
            color: #721c24;
            background-color: #ffffff !important;
            border-radius: 10px;
            margin: 20px 0;
        }

        /* REGLA SUPER IMPORTANTE para eliminar cualquier gradiente */
        * {
            background-image: none !important;
        }

        /* Fuerza el fondo blanco en todos los elementos anidados */
        html,
        body,
        div,
        section,
        main,
        article,
        .container,
        .wrapper {
            background-color: #ffffff !important;
        }

        /* Elimina cualquier sombra o efecto de fondo */
        .card,
        .panel,
        .box,
        .frame {
            background: white !important;
            box-shadow: none !important;
        }
    </style>
</head>

<body>
    <!-- Welcome message -->
    <h1>Welcome, <span class="admin-name"><?= htmlspecialchars($adminName); ?></span></h1>
    <p class="subtitle">Admin Dashboard - Personal Curriculum</p>

    <!-- CV content -->
    <?php if ($cvFilePath && file_exists($cvFilePath)): ?>
        <!-- Mostrar el CV en un iframe -->
        <iframe src="<?= htmlspecialchars($cvFilePath); ?>"
            class="cv-frame"
            title="Curriculum de <?= htmlspecialchars($adminName); ?>"
            id="cv-frame"></iframe>

        <!-- Contenedor oculto con el contenido HTML para PDF -->
        <div id="cv-html-content" style="display: none;">
            <?= $cvContent; ?>
        </div>
    <?php else: ?>
        <!-- Mostrar mensaje de error si no hay CV -->
        <div class="cv-content cv-error">
            <h3>CV no disponible</h3>
            <p>No se pudo cargar el curriculum. Por favor, verifica que el archivo exista.</p>
            <p><small>Email: <?= htmlspecialchars($adminEmail); ?></small></p>
            <p><small>Ruta esperada: <?= htmlspecialchars($cvFilePath ?? 'No configurada'); ?></small></p>
        </div>
    <?php endif; ?>

    <!-- Botones -->
    <div class="button-container">
        <button class="btn btn-download" onclick="downloadCVasPDF()">Download CV as PDF</button>
        <button class="btn btn-edit" onclick="editCV()">Edit CV</button>
        <a href="logout.php" class="btn btn-logout">Logout</a>
    </div>

    <script>
        // Mapeo de correos a rutas de archivos
        const adminCVPaths = {
            'cristian@gmail.com': '../cv_cristian/index.html',
            'kevin@gmail.com': '../cv_kevin/index.html',
            'stefanny@gmail.com': '../cv_stefanny/index.html',
            'camilo@gmail.com': '../cv_camilo/index.html'
        };

        const adminEmail = "<?= $adminEmail; ?>";
        const adminName = "<?= $adminName; ?>";

        // Función para descargar como PDF
        async function downloadCVasPDF() {
            alert('Generando PDF... Por favor espere.');

            // Verificar si html2pdf está cargado
            if (typeof html2pdf === 'undefined') {
                alert('Error: La librería html2pdf no se cargó correctamente. Recargue la página.');
                return;
            }

            try {
                // Para todos los admins: Intentar generar PDF del contenido del iframe
                const iframe = document.getElementById('cv-frame');

                if (!iframe) {
                    throw new Error('No se encontró el CV para generar PDF');
                }

                // Intentar acceder al contenido del iframe
                const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                const iframeContent = iframeDoc.documentElement;

                const options = {
                    margin: [10, 10, 10, 10],
                    filename: `CV_${adminName}.pdf`,
                    image: {
                        type: 'jpeg',
                        quality: 0.98
                    },
                    html2canvas: {
                        scale: 2,
                        useCORS: true,
                        backgroundColor: '#ffffff',
                        logging: false
                    },
                    jsPDF: {
                        unit: 'mm',
                        format: 'a4',
                        orientation: 'portrait'
                    }
                };

                await html2pdf().set(options).from(iframeContent).save();
                console.log('PDF generado exitosamente');

            } catch (error) {
                console.error('Error al generar PDF:', error);

                // Si hay error de CORS, ofrecer alternativas
                alert('No se pudo generar PDF automáticamente. Intentando método alternativo...');

                // Método alternativo 1: Descargar el archivo HTML directamente
                if (adminCVPaths[adminEmail]) {
                    const link = document.createElement('a');
                    link.href = adminCVPaths[adminEmail];
                    link.download = `CV_${adminName}.html`;
                    link.target = '_blank';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                } else {
                    // Método alternativo 2: Descargar contenido como texto
                    downloadAsText();
                }
            }
        }

        // Función para descargar como texto plano
        function downloadAsText() {
            const cvContent = document.getElementById('cv-html-content')?.innerText ||
                document.querySelector('.cv-content')?.innerText ||
                'CV content not available';

            const blob = new Blob([cvContent], {
                type: 'text/plain'
            });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `CV_${adminName}.txt`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }

        // Función para editar el CV
        function editCV() {
            if (adminCVPaths[adminEmail]) {
                // Abrir el archivo HTML en una nueva pestaña para editar
                window.open(adminCVPaths[adminEmail], '_blank');
            } else {
                alert('No se puede editar: CV no encontrado.');
            }
        }

        // Función para extraer contenido del iframe de forma segura
        function getIframeContentSafely() {
            return new Promise((resolve, reject) => {
                const iframe = document.getElementById('cv-frame');
                if (!iframe) {
                    reject(new Error('Iframe no encontrado'));
                    return;
                }

                // Si el iframe ya está cargado
                if (iframe.contentDocument) {
                    resolve(iframe.contentDocument.documentElement.outerHTML);
                } else {
                    // Esperar a que cargue
                    iframe.onload = function() {
                        try {
                            const content = iframe.contentDocument.documentElement.outerHTML;
                            resolve(content);
                        } catch (e) {
                            reject(e);
                        }
                    };

                    // Si ya está cargado pero no tenemos acceso
                    setTimeout(() => {
                        try {
                            const content = iframe.contentDocument.documentElement.outerHTML;
                            resolve(content);
                        } catch (e) {
                            reject(e);
                        }
                    }, 1000);
                }
            });
        }
    </script>
</body>

</html>
<?php
session_start();

// Verificar que el usuario esté logueado Y sea administrador
if (!isset($_SESSION['email']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// Determinar qué admin es y cargar su CV específico
$adminEmail = $_SESSION['email'];
$adminName = $_SESSION['name'];

// Mapeo de admins a sus carpetas de CV HTML
$adminCVs = [
    'cristian@gmail.com' => '../cv/cv_cristian/index.html',
    'kevin@gmail.com' => '../cv/cv_kevin/index.html',
    'stefanny@gmail.com' => '../cv/cv_stefanny/index.html',
    'camilo@gmail.com' => '../cv/cv_camilo/index.html'
];

// Mapeo de admins a sus archivos PDF (debes crear estos archivos)
$adminPDFs = [
    'cristian@gmail.com' => '../cv_pdf/cv_cristian.pdf',
    'kevin@gmail.com' => '../cv_pdf/cv_kevin.pdf',
    'stefanny@gmail.com' => '../cv_pdf/cv_stefanny.pdf',
    'camilo@gmail.com' => '../cv_pdf/cv_camilo.pdf'
];

// Obtener la ruta del archivo HTML para el iframe
$cvFilePath = isset($adminCVs[$adminEmail]) ? $adminCVs[$adminEmail] : null;

// Obtener la ruta del archivo PDF para descargar
$pdfFilePath = isset($adminPDFs[$adminEmail]) ? $adminPDFs[$adminEmail] : null;
$pdfFileName = 'CV_' . str_replace(' ', '_', $adminName) . '.pdf';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?= htmlspecialchars($adminName); ?></title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #ffffff !important;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        /* Fuerza el fondo blanco en todos los elementos posibles */
        body::before,
        body::after,
        .app,
        .main-content,
        .page-wrapper,
        [class*="background"],
        [class*="bg-"] {
            background: #ffffff !important;
            background-image: none !important;
        }

        /* Welcome message */
        h1 {
            text-align: center;
            color: #333;
            margin: 40px 0 10px 0;
            font-size: 2.5em;
            width: 100%;
        }

        .admin-name {
            color: #4a6cf7;
        }

        /* Subtítulo */
        p.subtitle {
            text-align: center;
            color: #666;
            margin: 0 0 40px 0;
            font-size: 1.2em;
            width: 100%;
        }

        /* CV content */
        .cv-frame {
            width: 90%;
            max-width: 1200px;
            height: 600px;
            border: none;
            margin: 0 0 40px 0;
            background: white !important;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        /* Botones */
        .button-container {
            display: flex;
            gap: 15px;
            margin-top: auto;
            margin-bottom: 40px;
        }

        .btn {
            padding: 0;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            transition: all 0.3s;
            text-align: center;
            width: 180px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-sizing: border-box;
            line-height: 1;
            text-decoration: none;
            color: white;
            font-family: Arial, sans-serif;
            margin: 0;
        }

        .btn-logout {
            background: #dc3545;
        }

        .btn-logout:hover {
            background: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3);
        }

        .btn-download {
            background: #28a745;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .btn-download:hover {
            background: #218838;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(40, 167, 69, 0.3);
        }

        .btn-download:disabled {
            background: #6c757d;
            cursor: not-allowed;
            opacity: 0.6;
        }

        .btn-download:disabled:hover {
            transform: none;
            box-shadow: none;
        }

        /* Estilo para mensajes de error */
        .cv-error {
            text-align: center;
            padding: 40px;
            color: #721c24;
            background-color: #f8d7da !important;
            border: 1px solid #f5c6cb;
            border-radius: 10px;
            margin: 20px 0;
            width: 90%;
            max-width: 1200px;
        }

        .pdf-error {
            text-align: center;
            padding: 15px;
            color: #856404;
            background-color: #fff3cd !important;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            margin: 10px 0;
            width: 90%;
            max-width: 1200px;
        }

        /* REGLA SUPER IMPORTANTE para eliminar cualquier gradiente */
        * {
            background-image: none !important;
        }

        /* Fuerza el fondo blanco en todos los elementos anidados */
        html,
        body,
        div,
        section,
        main,
        article,
        .container,
        .wrapper {
            background-color: #ffffff !important;
        }

        /* Elimina cualquier sombra o efecto de fondo */
        .card,
        .panel,
        .box,
        .frame {
            background: white !important;
        }
    </style>
</head>

<body>
    <!-- Welcome message -->
    <h1>Bienvenido, <span class="admin-name"><?= htmlspecialchars($adminName); ?></span></h1>
    <p class="subtitle">Administra tu currículum personal</p>

    <!-- CV content -->
    <?php if ($cvFilePath && file_exists($cvFilePath)): ?>
        <!-- Mostrar el CV en un iframe -->
        <iframe src="<?= htmlspecialchars($cvFilePath); ?>"
            class="cv-frame"
            title="Curriculum de <?= htmlspecialchars($adminName); ?>"
            id="cv-frame"></iframe>
    <?php else: ?>
        <!-- Mostrar mensaje de error si no hay CV -->
        <div class="cv-error">
            <h3>CV no disponible</h3>
            <p>No se pudo cargar el curriculum. Por favor, verifica que el archivo exista.</p>
            <p><small>Email: <?= htmlspecialchars($adminEmail); ?></small></p>
            <p><small>Ruta esperada: <?= htmlspecialchars($cvFilePath ?? 'No configurada'); ?></small></p>
        </div>
    <?php endif; ?>

    <!-- Mensaje si el PDF no está disponible -->
    <?php if (!$pdfFilePath || !file_exists($pdfFilePath)): ?>
        <div class="pdf-error">
            <p><strong>⚠ Nota:</strong> El archivo PDF de tu CV no está disponible para descarga.</p>
            <p><small>Contacta al administrador para generar el archivo: <?= htmlspecialchars($pdfFileName); ?></small></p>
        </div>
    <?php endif; ?>

    <!-- Botones -->
    <div class="button-container">
        <?php if ($pdfFilePath && file_exists($pdfFilePath)): ?>
            <!-- Botón de descargar PDF -->
            <a href="<?= htmlspecialchars($pdfFilePath); ?>"
                download="<?= htmlspecialchars($pdfFileName); ?>"
                class="btn btn-download">
                Descargar CV en PDF
            </a>
        <?php else: ?>
            <!-- Botón deshabilitado si no hay PDF -->
            <button class="btn btn-download" disabled>
                Descargar CV en PDF
            </button>
        <?php endif; ?>

        <!-- Botón de logout -->
        <a href="logout.php" class="btn btn-logout">Cerrar sesión</a>
    </div>

</body>

</html>
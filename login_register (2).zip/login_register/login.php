<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once 'config.php';

// ==================== SOLO LOGIN PARA ADMINS ====================
if (isset($_POST['login'])) {
    // Validación
    if (empty($_POST['email']) || empty($_POST['password'])) {
        $_SESSION['login_error'] = 'Email and password are required!';
        header("Location: index.php");
        exit();
    }

    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Query user by email - SOLO ADMINISTRADORES
    $result = $conn->query("SELECT * FROM users WHERE email = '$email' AND role = 'admin'");

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $user['password'])) {
            $_SESSION['name'] = $user['name'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];

            // Solo redirigir a admin_page.php
            header("Location: admin_page.php");
            exit();
        } else {
            $_SESSION['login_error'] = 'Incorrect email or password';
            header("Location: index.php");
            exit();
        }
    } else {
        $_SESSION['login_error'] = 'Access denied. Only administrators can login.';
        header("Location: index.php");
        exit();
    }
}

// ==================== REDIRECCIÓN POR DEFECTO ====================
// Si no es login, redirigir al index
header("Location: index.php");
exit();
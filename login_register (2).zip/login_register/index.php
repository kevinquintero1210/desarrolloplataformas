<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Administradores</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <!-- Botón Home -->
  <a href="http://localhost:3000/project/Project4/inicio/home.html" class="home-button">Inicio</a>

  <div class="container">
    <div class="form-box active" id="login-form">
      <!-- Logo -->
      <div class="logo" style="text-align: center; margin-bottom: 8px;">
        <span style="font-size: 42px; font-weight: 800; color: #ffffff; letter-spacing: 0.5px;">
          Proyect<span class="logo-number">4</span>
        </span>
      </div>

      <form action="login.php" method="post">
        <h2>Acceso Admins</h2>

        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Contraseña" required>
        <button type="submit" name="login">Ingresar</button>
      </form>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      document.querySelector('input[name="email"]').focus();
    });
  </script>
</body>

</html>
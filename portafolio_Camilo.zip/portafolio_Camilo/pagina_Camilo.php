<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <link href="https://cdn.jsdelivr.net/npm/remixicon@3.2.0/fonts/remixicon.css" rel="stylesheet" />
  <link rel="stylesheet" href="perfil.css" />
  <title>Portfolio | Camilo</title>
</head>

<body>
  <!-- NAV -->
  <nav>
    <div class="nav__content">
      <div class="logo"><a href="#home">Camio Silva</a></div>
      <label for="check" class="checkbox">
        <i class="ri-menu-line"></i>
      </label>
      <input type="checkbox" name="check" id="check" />
      <ul>
        <li><a href="#home" class="active">inicio</a></li>
        <li><a href="#skills">Habilidades</a></li>
        <li><a href="#education">Educación</a></li>
        <li><a href="#experience">Experiencia</a></li>
        <li><a href="#projects">Proyectos</a></li>
        <li><a href="#contact">Contacto</a></li>
      </ul>
    </div>
  </nav>

  <!-- HOME -->
  <section class="section" id="home">
    <div class="section__container">
      <div class="image">
        <img src="/img/imgcamilo.jpg" alt="profile" />
      </div>
      <div class="content">
        <p class="subtitle">Hola</p>
        <h1 class="title"> Yo soy <span>Camilo</span> Estudiante de Ingeniería de Sistemas-Desarrollador </h1>
        <p class="description">
          Bienvenido a mi portafolio de desarrollador web! Soy Camilo, un desarrollador web habilidoso y creativo con
          pasión por crear sitios web hermosos, responsivos y fáciles de usar.
        </p>
        <div class="social-icons">
          <a href="#"><i class="fa-brands fa-linkedin"></i></a>
          <a href="#"><i class="fa-brands fa-github"></i></a>
          <a href="#"><i class="fa-brands fa-x-twitter"></i></a>
          <a href="#"><i class="fa-brands fa-instagram"></i></a>
        </div>
        <div class="action__btns">
          <button class="hire__me">contratame</button>
          <button class="portfolio">Portfolio</button>
        </div>
      </div>
    </div>
  </section>

  <!-- SKILLS -->
  <section class="section" id="skills">
    <div class="section__container">
      <div class="content">
        <p class="subtitle">Mis Habilidades</p>
        <h1 class="title">Habilidades <span>Técnicas</span></h1>
        <p class="description">Algunas de las tecnologías y herramientas que uso:</p>
        <div class="content-list">
          <p class="list-item">HTML5 / CSS3</p>
          <p class="list-item">JavaScript / ES6+</p>
          <p class="list-item">React / Node.js</p>
          <p class="list-item">Git / GitHub</p>
          <p class="list-item">Diseño Responsivo</p>
        </div>
      </div>
    </div>
  </section>

  <!-- EDUCATION -->
  <section class="section" id="education">
    <div class="section__container">
      <div class="content">
        <p class="subtitle">EDUCACIÓN</p>
        <h1 class="title">Mi <span>Educación</span></h1>
        <p class="description">Antecedentes académicos y certificaciones:</p>
        <div class="content-list">
          <p class="list-item">Ingenieria de Software – Universidad de Pamplona</p>
          <p class="list-item">Tecnico en Programación de Software – SENA</p>
          <p class="list-item">Diseño web – Bootcamp en Linea</p>
        </div>
      </div>
    </div>
  </section>

  <!-- EXPERIENCE -->
  <section class="section" id="experience">
    <div class="section__container">
      <div class="content">
        <p class="subtitle">EXPERIENCIA</p>
        <h1 class="title">experiencia <span>Laboral</span></h1>
        <p class="description">Experiencia relevante que he adquirido:</p>
        <div class="experience-container">
          <div class="timeline">
            <!-- Experiencia 1 -->
            <div class="timeline-item">
              <div class="timeline-content">
                <div class="experience-item">
                  <span class="experience-dot"></span>
                  <div class="experience-header">
                    <p class="experience-year">2023 - 2025</p>
                    <h3 class="experience-company">Proyectos Académicos</h3>
                  </div>
                  <p class="experience-desc">
                    Desarrollo de sistemas en Java, scripts SQL, implementación de árboles binarios, matrices dispersas
                    y sistemas de información. Construcción de proyectos completos como sistemas de PQRS y modelamiento
                    de bases de datos. </p>
                  <div class="experience-tech-container">
                    <span class="tech-item">Java</span>
                    <span class="tech-item">SQL</span>
                    <span class="tech-item">JavaScript</span>
                    <span class="tech-item">MBD</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- Experiencia 2 -->
            <div class="timeline-item">
              <div class="timeline-content">
                <div class="experience-item">
                  <span class="experience-dot"></span>
                  <div class="experience-header">
                    <p class="experience-year">2022 - 2024</p>
                    <h3 class="experience-company">Proyectos Independientes</h3>
                  </div>
                  <p class="experience-desc">
                    Desarrollo de aplicaciones básicas web y de escritorio, experimentación con APIs, creación de pequeños
                    sistemas CRUD, y práctica constante con Java, HTML, CSS y JavaScript.
                  </p>
                  <div class="experience-tech-container">
                    <span class="tech-item">HTML</span>
                    <span class="tech-item">CSS</span>
                    <span class="tech-item">JavaScript</span>
                    <span class="tech-item">Java</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- Experiencia 3 -->
            <div class="timeline-item">
              <div class="timeline-content">
                <div class="experience-item">
                  <span class="experience-dot"></span>
                  <div class="experience-header">
                    <p class="experience-year">2023 - 2025</p>
                    <h3 class="experience-company">Proyectos Académicos</h3>
                  </div>
                  <p class="experience-desc">
                    Desarrollo de aplicaciones en Java, sistemas de gestión (PQRS), modelamiento de bases de datos con MER y
                    modelo relacional, creación de scripts SQL, implementación de estructuras como árboles binarios y matrices
                    dispersas, además de análisis funcional y diseño de sistemas.
                  </p>
                  <div class="experience-tech-container">
                    <span class="tech-item">PQRS</span>
                    <span class="tech-item">SQL</span>
                    <span class="tech-item">MER</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- PROJECTS -->
  <section class="section" id="projects">
    <div class="section__container">
      <div class="content">
        <p class="subtitle">PROYECTOS</p>
        <h1 class="title">Mis <span>Proyectos</span></h1>
        <p class="description">Algunos proyectos que he desarrollado recientemente:</p>
        <div class="content-list">

          <div class="project-card">
            <div class="project-img">
              <img src="/img/proyecto.jpg" alt="proyecto 1">
            </div>
            <div class="project-info">
              <h3>App de Gestión de tareas</h3>
              <p>Aplicación diseñada para gestionar diferentes tareas de tu día a día</p>
              <div class="project-tech">
                <span>HTML</span>
                <span>CSS</span>
                <span>JavaScript</span>
              </div>
              <div class="project-links">
                <a href="#" target="_blank"><i class="fas fa-link"></i>Demo</a>
                <a href="#" target="_blank"><i class="fab fa-github"></i>Codigo</a>
              </div>
            </div>
          </div>

          <div class="project-card">
            <div class="project-img">
              <img src="/img/proyecto.jpg" alt="proyecto 2">
            </div>
            <div class="project-info">
              <h3>App de reservas de citas</h3>
              <p>Aplicación diseñada para gestionar diferentes tareas de tu día a día</p>
              <div class="project-tech">
                <span>HTML</span>
                <span>CSS</span>
                <span>JavaScript</span>
              </div>
              <div class="project-links">
                <a href="#" target="_blank"><i class="fas fa-link"></i>Demo</a>
                <a href="#" target="_blank"><i class="fab fa-github"></i>Codigo</a>
              </div>
            </div>
          </div>

          <div class="project-card">
            <div class="project-img">
              <img src="/img/proyecto.jpg" alt="proyecto 3">
            </div>
            <div class="project-info">
              <h3>App de control de gastos e ingresos</h3>
              <p>Aplicación diseñada para gestionar diferentes tareas de tu día a día</p>
              <div class="project-tech">
                <span>HTML</span>
                <span>CSS</span>
                <span>JavaScript</span>
              </div>
              <div class="project-links">
                <a href="#" target="_blank"><i class="fas fa-link"></i>Demo</a>
                <a href="#" target="_blank"><i class="fab fa-github"></i>Codigo</a>
              </div>
            </div>
          </div>

          <div class="project-card">
            <div class="project-img">
              <img src="/img/proyecto.jpg" alt="proyecto 2">
            </div>
            <div class="project-info">
              <h3>App de reservas de citas</h3>
              <p>Aplicación diseñada para gestionar diferentes tareas de tu día a día</p>
              <div class="project-tech">
                <span>HTML</span>
                <span>CSS</span>
                <span>JavaScript</span>
              </div>
              <div class="project-links">
                <a href="#" target="_blank"><i class="fas fa-link"></i>Demo</a>
                <a href="#" target="_blank"><i class="fab fa-github"></i>Codigo</a>
              </div>
            </div>
          </div>

          <div class="project-card">
            <div class="project-img">
              <img src="/img/proyecto.jpg" alt="proyecto 2">
            </div>
            <div class="project-info">
              <h3>App de reservas de citas</h3>
              <p>Aplicación diseñada para gestionar diferentes tareas de tu día a día</p>
              <div class="project-tech">
                <span>HTML</span>
                <span>CSS</span>
                <span>JavaScript</span>
              </div>
              <div class="project-links">
                <a href="#" target="_blank"><i class="fas fa-link"></i>Demo</a>
                <a href="#" target="_blank"><i class="fab fa-github"></i>Codigo</a>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer class="footer" id="contact">
    <div class="footer__container">
      <h2 class="footer__name">Camilo</h2>
      <div class="footer-icons">
        <a href="#"><i class="fa-brands fa-linkedin"></i></a>
        <a href="#"><i class="fa-brands fa-github"></i></a>
        <a href="#"><i class="fa-brands fa-x-twitter"></i></a>
        <a href="#"><i class="fa-brands fa-instagram"></i></a>
      </div>
      <p class="footer__text">No dudes en contactarme para consultas de colaboración o trabajo:</p>
      <div class="footer__info">
        <p>Email: daniel.silvagarcia1978@gmail.com</p>
        <p>Celular: +57 3204456119</p>
        <p>Ubicación: Colombia</p>
      </div>
      <p class="footer__rights">© 2025 Camilo — Todos los derechos reservados.</p>
    </div>
  </footer>

  <!-- SCRIPT -->
  <script>
    const sectionsAndFooter = document.querySelectorAll("section, footer");
    const navLinks = document.querySelectorAll("nav ul li a");
    const checkbox = document.getElementById("check");

    // cerrar menú movil al pulsar enlace
    navLinks.forEach(link => {
      link.addEventListener("click", () => {
        checkbox.checked = false;
      });
    });

    navLinks.forEach(link => {
      link.addEventListener("click", (e) => {
        const href = link.getAttribute('href');
        if (!href || !href.startsWith('#')) return;
        e.preventDefault();
        const target = document.querySelector(href);
        if (!target) return;
        navLinks.forEach(l => l.classList.remove('active'));
        link.classList.add('active');
        target.scrollIntoView({ behavior: 'auto', block: 'start' });
        if (checkbox) checkbox.checked = false;
      });
    });

    const observerOptions = { root: null, rootMargin: '-35% 0px -35% 0px', threshold: 0 };
    const observerCallback = (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const id = entry.target.getAttribute('id');
          if (!id) return;
          navLinks.forEach(link => {
            link.classList.toggle('active', link.getAttribute('href') === '#' + id);
          });
        }
      });
    };
    const observer = new IntersectionObserver(observerCallback, observerOptions);
    sectionsAndFooter.forEach(el => observer.observe(el));
  </script>
</body>

</html>